/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package directory;

import java.io.Serializable;

/**
 *
 * @author edwarffein
 */
public class Contact {

    private String name, lastnames, telephone;

    public Contact(String name, String lastnames, String telephone) {
        this.name = name;
        this.lastnames = lastnames;
        this.telephone = telephone;
    }
    
    public Contact() {
        
    }
    
    public String getLastnames() {
        return lastnames;
    }

    public String getName() {
        return name;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setLastnames(String lastnames) {
        this.lastnames = lastnames;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }
    
}
