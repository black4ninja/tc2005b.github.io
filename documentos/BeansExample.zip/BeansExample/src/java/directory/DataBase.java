/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package directory;

import java.sql.*;
import java.util.*;

/**
 *
 * @author Eduardo Juárez
 */
public class DataBase {
    
    Connection connection=null;
	
    public DataBase() {
        connection=null;
    }

    public boolean connect(){
	try {
            String urlBD = "jdbc:mysql://localhost/dadi_jspexample?user=root&password="; 
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            connection = DriverManager.getConnection(urlBD);
        } catch (Exception e) { 
	    System.out.println(e);
            return false;
	}
        return true;
    }
    
    private boolean close() {
        try {
            connection.close(); 
            return true;
        } catch (Exception e) { 
	    System.out.println(e);
            return false;
	}
    }
    
    public boolean insert(Contact c) {
        try {
	      connect();
              String q="insert into directory(name,lastnames,telephone) values(?,?,?)";
              PreparedStatement i=connection.prepareStatement(q);
	      i.setString(1,c.getName());
	      i.setString(2,c.getLastnames());
	      i.setString(3,c.getTelephone());
	      i.executeUpdate();
	      i.close(); 
              close();
              return true;
        } catch (Exception e) { 
            System.out.println(e);
            return false;
        }
    }

    //gives back a collection for the directory.
    public Collection getDirectory() {
        Collection c = new ArrayList();
        try{
            if (connect()){
                String q="select * from directory";
                PreparedStatement p=connection.prepareStatement(q);
	        ResultSet r=p.executeQuery();
  	        while(r.next()) {
                    Contact contact = new Contact(r.getString(1), r.getString(2), r.getString(3));
                    c.add(contact);
                }
	        r.close();
                p.close();
	        close();
                return c;
            } 
            return c;
            
	 } catch (Exception e) { 
   	    System.out.println(e);
            return c;
         }
        
    }
}
