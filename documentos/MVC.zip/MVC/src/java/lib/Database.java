/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lib;

import java.sql.*;
import java.util.*;
import model.Credit;

/**
 *
 * @author Eduardo Juárez
 */
public class Database {
    
    Connection connection=null;
	
    public Database() {
        connection=null;
    }

    public boolean connect(){
	try {
            String urlBD = "jdbc:mysql://localhost/dadi_credit?user=root&password="; 
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            connection = DriverManager.getConnection(urlBD);
        } catch (Exception e) { 
	    System.out.println(e);
            return false;
	}
        return true;
    }
    
    private boolean close() {
        try {
            connection.close(); 
            return true;
        } catch (Exception e) { 
	    System.out.println(e);
            return false;
	}
    }
    
    public Credit getCredit(String card) {
        try{
            if (connect()) {
                String q="select * from credit where card=?";
                PreparedStatement p=connection.prepareStatement(q);
                p.setString(1,card);
                ResultSet r = p.executeQuery();
                Credit credit = null;
                if (r.next()) {
                    credit = new Credit(r.getString("client"), r.getString("card"), r.getDouble("balance"), r.getDouble("limit"));
                }
                r.close();
                p.close();
                return credit;
            }
            else
                return null;
        } catch (Exception e) { 
            System.out.println(e);
            return null;
        }
    }
}
