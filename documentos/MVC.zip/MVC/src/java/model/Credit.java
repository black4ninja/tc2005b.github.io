/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author eEduardo Juárez
 */
public class Credit {
    private String client;
    private String card;
    private double balance;
    private double limit;

    public Credit() {
    }

    public Credit(String client, String card, double balance, double limit) {
        this.client = client;
        this.card = card;
        this.balance = balance;
        this.limit = limit;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getCard() {
        return card;
    }

    public void setCard(String card) {
        this.card = card;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public double getLimit() {
        return limit;
    }

    public void setLimit(double limit) {
        this.limit = limit;
    }
     
    public String getStatus() {
        if (this.getBalance() == this.getLimit())
            return "Warning";
        else if (this.getBalance() < this.getLimit())
            return "Good behaviour";
        else
            return "Overdraft";
    }
}
