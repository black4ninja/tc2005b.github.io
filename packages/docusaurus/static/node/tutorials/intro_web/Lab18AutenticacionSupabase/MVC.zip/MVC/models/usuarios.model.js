// Este archivo se completará durante el laboratorio de autenticación.
// Aquí irá el modelo de Usuario con las funciones save() y findByUsername().
