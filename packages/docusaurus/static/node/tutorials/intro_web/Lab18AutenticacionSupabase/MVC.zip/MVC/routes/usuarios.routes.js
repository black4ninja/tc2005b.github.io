const express = require('express');
const router = express.Router();

// Las rutas se completarán durante el laboratorio de autenticación.
// Aquí irán las rutas de registro, login y rutas protegidas.

router.get('/test_json', (req, res) => {
    res.status(200).json({ code: 200, msg: "Ok" });
});

module.exports = router;
