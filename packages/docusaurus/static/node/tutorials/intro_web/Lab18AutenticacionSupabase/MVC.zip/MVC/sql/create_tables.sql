-- Ejecutar en el SQL Editor de Supabase antes de iniciar el laboratorio

CREATE TABLE IF NOT EXISTS users (
    id        SERIAL PRIMARY KEY,
    username  VARCHAR(60)  NOT NULL UNIQUE,
    name      VARCHAR(120),
    password  VARCHAR(255) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_users_username ON users (username);

-- =============================================================
-- LIMPIAR DATOS (ejecutar cuando quieras reiniciar el ejercicio)
-- =============================================================

-- Opcion 1: Borrar todos los usuarios pero mantener la tabla
-- TRUNCATE TABLE users RESTART IDENTITY;

-- Opcion 2: Eliminar la tabla por completo (hay que volver a crearla)
-- DROP TABLE IF EXISTS users;
