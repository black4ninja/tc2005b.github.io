// Este archivo se completará durante el laboratorio de autenticación.
// Aquí irán los controladores de registro, login y rutas protegidas.
