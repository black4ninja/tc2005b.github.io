const model   = require('../models/document.model.js');
const storage = require('../models/storage.repository.js');

const PUBLIC_BUCKET  = process.env.PUBLIC_BUCKET  || 'lab28-public';
const PRIVATE_BUCKET = process.env.PRIVATE_BUCKET || 'lab28-private';

// GET /documents/new — solo renderiza el form vacío.
module.exports.showCreate = (req, res) => {
    res.render('upload', { error: null });
};

module.exports.create = async (req, res) => {
    if (!req.file) {
        return res.status(400).render('upload', { error: 'Falta el archivo.' });
    }
    const title    = (req.body.title || '').trim() || req.file.originalname;
    const isPublic = req.body.is_public === 'on';
    const bucket   = isPublic ? PUBLIC_BUCKET : PRIVATE_BUCKET;
    const filePath = storage.buildObjectPath(req.file.originalname);

    // 1) Subir a Storage.
    try {
        await storage.uploadObject(bucket, filePath, req.file.buffer, req.file.mimetype);
    } catch (e) {
        return res.status(500).render('upload', { error: 'Error subiendo a Storage: ' + e.message });
    }

    // 2) INSERT en BD. Si falla, COMPENSAR borrando el objeto recién subido.
    try {
        await model.create({
            title, file_path: filePath, bucket,
            mime_type: req.file.mimetype, size_bytes: req.file.size, is_public: isPublic
        });
    } catch (e) {
        try { await storage.removeObject(bucket, filePath); }
        catch (e2) { console.log('Compensación también falló:', e2.message); }
        return res.status(500).render('upload', { error: 'Error registrando en BD: ' + e.message });
    }

    res.redirect('/documents?flash=creado');
};

// GET /documents — lista todos los documentos.
module.exports.index = async (req, res) => {
    try {
        const docs = await model.findAll();
        // Para los documentos públicos calculamos la URL al renderizar (no la
        // persistimos en BD). Para los privados no calculamos nada: la vista
        // pedirá la signed URL después con fetch.
        const enriched = docs.map(doc => ({
            ...doc,
            publicUrl: doc.is_public
                ? storage.getPublicUrl(doc.bucket, doc.file_path)
                : null
        }));
        res.render('documents', { docs: enriched, flash: req.query.flash });
    } catch (e) {
        console.log(e);
        res.status(500).send('Error al listar documentos');
    }
};

// GET /documents/:id — detalle de un documento.
module.exports.show = async (req, res) => {
    try {
        const doc = await model.findById(req.params.id);
        if (!doc) return res.status(404).send('Documento no encontrado');

        const publicUrl = doc.is_public
            ? storage.getPublicUrl(doc.bucket, doc.file_path)
            : null;

        res.render('document', { doc, publicUrl });
    } catch (e) {
        console.log(e);
        res.status(500).send('Error al obtener el documento');
    }
};

// GET /documents/:id/edit — formulario de edición precargado.
module.exports.showEdit = async (req, res) => {
    try {
        const doc = await model.findById(req.params.id);
        if (!doc) return res.status(404).send('Documento no encontrado');
        res.render('edit', { doc, error: null });
    } catch (e) {
        console.log(e);
        res.status(500).send('Error al cargar la edición');
    }
};

// POST /documents/:id — actualiza metadata y/o reemplaza el archivo.
module.exports.update = async (req, res) => {
    const id = req.params.id;
    let doc;
    try {
        doc = await model.findById(id);
        if (!doc) return res.status(404).send('Documento no encontrado');
    } catch (e) {
        console.log(e);
        return res.status(500).send('Error al cargar el documento');
    }

    const newTitle = (req.body.title || '').trim() || doc.title;

    // ── Caso A: no vino archivo nuevo → solo actualizamos el título.
    if (!req.file) {
        try {
            await model.updateMetadata(id, { title: newTitle });
        } catch (e) {
            return res.status(500).render('edit', { doc, error: 'Error al actualizar: ' + e.message });
        }
        return res.redirect('/documents/' + id + '?flash=actualizado');
    }

    // ── Caso B: vino archivo nuevo → reemplazo en 3 pasos.
    const newPath = storage.buildObjectPath(req.file.originalname);
    const oldPath = doc.file_path;

    // 1) Sube el nuevo. En este instante ambos archivos coexisten en Storage.
    try {
        await storage.uploadObject(doc.bucket, newPath, req.file.buffer, req.file.mimetype);
    } catch (e) {
        return res.status(500).render('edit', { doc, error: 'Error subiendo el archivo nuevo: ' + e.message });
    }

    // 2) Apunta la fila al nuevo. Si esto falla, COMPENSAR borrando el nuevo.
    try {
        await model.replaceFile(id, {
            file_path:  newPath,
            mime_type:  req.file.mimetype,
            size_bytes: req.file.size
        });
        if (newTitle !== doc.title) {
            await model.updateMetadata(id, { title: newTitle });
        }
    } catch (e) {
        try { await storage.removeObject(doc.bucket, newPath); }
        catch (e2) { console.log('Compensación también falló:', e2.message); }
        return res.status(500).render('edit', { doc, error: 'Error en BD: ' + e.message });
    }

    // 3) Ya está. Limpia el viejo. Si esto falla, no rompe nada: archivo huérfano.
    try { await storage.removeObject(doc.bucket, oldPath); }
    catch (e) { console.log('No se pudo borrar el archivo viejo:', e.message); }

    res.redirect('/documents/' + id + '?flash=reemplazado');
};

module.exports.destroy = async (req, res) => {
    const removed = await model.remove(req.params.id);     // 1) BD primero
    if (!removed) return res.status(404).send('No encontrado');
    try { await storage.removeObject(removed.bucket, removed.file_path); }  // 2) Storage después
    catch (e) { console.log('Archivo huérfano en Storage:', e.message); }
    res.redirect('/documents?flash=eliminado');
};

module.exports.getSignedUrl = async (req, res) => {
    const doc = await model.findById(req.params.id);
    if (!doc) return res.status(404).json({ error: 'No encontrado' });
    if (doc.is_public) {
        return res.json({ url: storage.getPublicUrl(doc.bucket, doc.file_path) });
    }
    // No pasamos tercer argumento: usamos el default (60 s) definido en
    // storage.repository.js. Si quieres cambiarlo, modifícalo en un solo lugar.
    const url = await storage.createSignedUrl(doc.bucket, doc.file_path);
    res.json({ url });
};
