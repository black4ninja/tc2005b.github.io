const pool = require('../util/database.js');

exports.create = async ({ title, file_path, bucket, mime_type, size_bytes, is_public }) => {
    const sql = `
        INSERT INTO documents (title, file_path, bucket, mime_type, size_bytes, is_public)
        VALUES ($1, $2, $3, $4, $5, $6)
        RETURNING *
    `;
    const { rows } = await pool.query(sql, [title, file_path, bucket, mime_type, size_bytes, is_public]);
    return rows[0];
};

exports.findAll = async () => {
    const { rows } = await pool.query(
        'SELECT * FROM documents ORDER BY uploaded_at DESC'
    );
    return rows;
};

exports.findById = async (id) => {
    const { rows } = await pool.query(
        'SELECT * FROM documents WHERE id = $1', [id]
    );
    return rows[0];
};

exports.updateMetadata = async (id, { title }) => {
    const { rows } = await pool.query(
        'UPDATE documents SET title = $1 WHERE id = $2 RETURNING *',
        [title, id]
    );
    return rows[0];
};

exports.replaceFile = async (id, { file_path, mime_type, size_bytes }) => {
    const sql = `
        UPDATE documents
        SET file_path  = $1,
            mime_type  = $2,
            size_bytes = $3,
            uploaded_at = NOW()
        WHERE id = $4
        RETURNING *
    `;
    const { rows } = await pool.query(sql, [file_path, mime_type, size_bytes, id]);
    return rows[0];
};

exports.remove = async (id) => {
    const { rows } = await pool.query(
        'DELETE FROM documents WHERE id = $1 RETURNING file_path, bucket',
        [id]
    );
    return rows[0];
};
