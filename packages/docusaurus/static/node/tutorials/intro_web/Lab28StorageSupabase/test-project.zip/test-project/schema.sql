DROP TABLE IF EXISTS documents CASCADE;

CREATE TABLE documents (
    id           SERIAL PRIMARY KEY,
    title        VARCHAR(160) NOT NULL,
    file_path    TEXT NOT NULL,
    bucket       VARCHAR(80) NOT NULL,
    mime_type    VARCHAR(120),
    size_bytes   BIGINT,
    is_public    BOOLEAN NOT NULL DEFAULT TRUE,
    uploaded_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_documents_uploaded_at ON documents (uploaded_at DESC);
