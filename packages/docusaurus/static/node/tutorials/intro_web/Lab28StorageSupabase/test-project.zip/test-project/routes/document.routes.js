const express = require('express');
const multer  = require('multer');
const router  = express.Router();
const controller = require('../controllers/document.controller.js');

const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 10 * 1024 * 1024 }  // 10 MB
});

router.get('/',                  controller.index);
router.get('/new',               controller.showCreate);
router.post('/',                 upload.single('file'), controller.create);
router.get('/:id',               controller.show);
router.get('/:id/edit',          controller.showEdit);
router.get('/:id/signed-url',    controller.getSignedUrl);
router.post('/:id',              upload.single('file'), controller.update);
router.post('/:id/delete',       controller.destroy);

module.exports = router;
