const crypto = require('crypto');
const path   = require('path');
const supabase = require('../util/storage.js');

// Construye un path único: "documents/{uuid}-{slug}.{ext}"
exports.buildObjectPath = (originalName) => {
    const ext = path.extname(originalName).toLowerCase();
    const base = path.basename(originalName, ext);
    const slug = base
        .toLowerCase()
        .normalize('NFD').replace(/[̀-ͯ]/g, '')  // quita acentos
        .replace(/[^a-z0-9]+/g, '-')                       // espacios/símbolos -> "-"
        .replace(/^-+|-+$/g, '')
        .slice(0, 40) || 'file';
    const uuid = crypto.randomUUID();
    return `documents/${uuid}-${slug}${ext}`;
};

exports.uploadObject = async (bucket, filePath, buffer, contentType) => {
    const { data, error } = await supabase
        .storage
        .from(bucket)
        .upload(filePath, buffer, { contentType, upsert: false });
    if (error) throw new Error(`Storage upload falló: ${error.message}`);
    return data;
};

exports.removeObject = async (bucket, filePath) => {
    const { data, error } = await supabase
        .storage
        .from(bucket)
        .remove([filePath]);
    if (error) throw new Error(`Storage remove falló: ${error.message}`);
    return data;
};

exports.getPublicUrl = (bucket, filePath) => {
    const { data } = supabase.storage.from(bucket).getPublicUrl(filePath);
    return data.publicUrl;
};

exports.createSignedUrl = async (bucket, filePath, expiresIn = 60) => {
    const { data, error } = await supabase
        .storage
        .from(bucket)
        .createSignedUrl(filePath, expiresIn);
    if (error) throw new Error(`createSignedUrl falló: ${error.message}`);
    return data.signedUrl;
};
