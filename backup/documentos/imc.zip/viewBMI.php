<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>BMI</title>
        <link rel="stylesheet" type="text/css" href="main.css" />
        <style type="text/css">
            h1 { color:red }
            p { color:green !important }
        </style>
    </head>
    <body>
        <h1>BMI</h1>
        <p style="color:blue">
            Your body mass index is <strong><?php echo $bmi ?></strong> 
            and the World Health Organization classifies it as <strong><?php echo $classification ?></strong>
        </p>
        <a href="index.php">Calculate again</a>
    </body>
</html>

