<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>BMI</title>
    </head>
    <body>
        <p>
            The World Health Organization classifies the BMI <?php echo $bmi ?> 
            as <strong><?php echo $classification ?></strong>
        </p>
        <a href="index.php">Calculate again</a>
    </body>
</html>
