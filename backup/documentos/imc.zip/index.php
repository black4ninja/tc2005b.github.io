<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>BMI</title>
        <link rel="stylesheet" type="text/css" href="main.css" />
    </head>
    <body>
        <h1>Get your body mass index (BMI)</h1>
        <form method="POST" action="controllerBMI.php">
            <table border="2" class="form">
                <tfoot>
                    <tr>
                        <td colspan="2">
                            <input type="submit" name="calculate" value="Calculate" id="calculate"/>
                            <input type="reset" class="reset" name="reset" value="Clean" id="reset"/>
                        </td>
                    </tr>
                </tfoot>
                <tbody>
                    <tr>
                        <th>
                            <label for="mass">Mass (kg)</label>
                        </th>
                        <td>
                            <input type="text" name= "mass" id="mass"/>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <label for="height">Height (m)</label>
                        </th>
                        <td>
                            <input type="text" name= "height" id="height"/>
                        </td>
                    </tr>        
                </tbody>
        </form>
    </body>
</html>

