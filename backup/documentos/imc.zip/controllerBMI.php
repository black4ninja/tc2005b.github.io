<?php
    //Obtiene la clasificación del IMC de acuerdo a la OMS
    function clasificacion($imc)
    {
        //Calcular la clasificación
        if ($imc < 18.5)
        {
            $clasificacion = "underweight";
        }
        elseif ($imc < 25)
        {
            $clasificacion = "normal";
        }
        else if ($imc < 30)
        {
            $clasificacion = "overweight";
        }
        else
        {
            $clasificacion = "obese";
        }
        return $clasificacion;
    }
    

    if (isset($_POST['calculate']) == 'Calculate')
    {
        //Calcular el IMC
        $bmi = $_POST["mass"] / pow($_POST["height"],2);
        
        $classification = clasificacion($bmi);
        
        //Invocar la vista
        include("viewBMI.php");            
    } 
    else if (isset($_GET['bmi']))
    {
        $bmi = $_GET['bmi'];
        $classification = clasificacion($bmi);
        //Invocar la vista
        include("viewClassification.php"); 
    }
    else
    {
        //Devolver error
        header("HTTP/1.1 404 Not Found");
    }
?>
